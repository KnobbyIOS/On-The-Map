//
//  UserDetailViewController.swift
//  On-The-Map
//
//  Created by Brian Leding on 9/12/19.
//  Copyright © 2019 Brian Leding. All rights reserved.
//

import MapKit
import UIKit
import CoreLocation

class UserDetailViewController: UIViewController, UITextFieldDelegate,MKMapViewDelegate {
    
    @IBOutlet weak var userLocation: UITextField!
    @IBOutlet weak var userURL: UITextField!
    
    @IBOutlet weak var findMeButton: UIButton!
    var geoCoder = CLGeocoder()
    var locationID: String?
    @IBOutlet weak var activityIndicator: UIActivityIndicatorView!
    
    override func viewWillAppear(_ animated: Bool) {
        subscribeToKeyboardNotifications()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        userLocation.delegate =  self
        userURL.delegate = self
        
        
    }
    
    deinit {
        NotificationCenter.default.removeObserver(self, name: NSNotification.Name.UIKeyboardWillShow, object: nil)
        NotificationCenter.default.removeObserver(self, name: NSNotification.Name.UIKeyboardWillHide, object: nil)
        NotificationCenter.default.removeObserver(self, name: NSNotification.Name.UIKeyboardWillChangeFrame, object: nil)
    }
    @IBAction func cancelButton(_ sender: Any) {
        userLocation.resignFirstResponder()
        userURL.resignFirstResponder()
        dismiss(animated: true, completion: nil)
    }
    @IBAction func findMeButton(_ sender: Any) {
        
        let newLocation = userLocation.text!
        let newWebsite = userURL.text!
        activityIndicator.startAnimating()
        activityIndicator.isHidden = false
        if newLocation.isEmpty || newWebsite.isEmpty {
            showInfo(withMessage: "All fields need to be filled.")
            activityIndicator.stopAnimating()
            activityIndicator.isHidden = true
            return
        } else {
            userLocation.resignFirstResponder()
            userURL.resignFirstResponder()
        }
        
        guard let newURL = URL(string: newWebsite), UIApplication.shared.canOpenURL(newURL) else {
            showInfo(withMessage: "Link invalid!")
            activityIndicator.stopAnimating()
            activityIndicator.isHidden = true
            return
        }
        print (newLocation)
        geocodePosition(newLocation: newLocation)
        
        
    }
    
    private func geocodePosition(newLocation: String) {
        geoCoder.geocodeAddressString(newLocation) { (newMarker, error) in
            self.activityIndicator.stopAnimating()
            self.activityIndicator.isHidden = true
            if let error = error {
                
                self.showInfo(withTitle: "Error", withMessage: "Unable to find location: \(error)")
            } else {
                var location: CLLocation?
                
                if let marker = newMarker, marker.count > 0 {
                    location = (marker.first?.location)!
                }
                
                if let location: CLLocationCoordinate2D = location?.coordinate {
                    print ("2")
                    print(location)
                    DispatchQueue.main.async {
                        
                        self.loadNewLocation(location)
                    }
                    return
                } else {
                    activityIndicator.stopAnimating()
                    activityIndicator.isHidden = true
                }
                self.showInfo(withMessage: "No Matching Location Found")
            }
        }
    }
    private func loadNewLocation(_ coordinate: CLLocationCoordinate2D) {
        
        print("loadNewLocation is getting called.")
        print(coordinate)
        let showNewLocation = storyboard?.instantiateViewController(withIdentifier: "MapPinDetailViewController") as! MapPinDetailViewController
        showNewLocation.studentDetails = buildStudentDetails(coordinate)
        self.present(showNewLocation, animated: true, completion: nil)
        activityIndicator.stopAnimating()
        activityIndicator.isHidden = true
        print("You should see map view")
    }
    
    private func buildStudentDetails(_ coordinates: CLLocationCoordinate2D) -> StudentDetails {
        print(coordinates)
        let nameComponents = DataClient.sharedInstance().userName.components(separatedBy: " ")
        let firstName = nameComponents.first ?? ""
        let surname = nameComponents.last ?? ""
        
        var studentInfo = [
            "uniqueKey": DataClient.sharedInstance().userKey,
            "firstName": firstName,
            "lastName": surname,
            "mapString": userLocation.text!,
            "mediaURL": userURL.text!,
            "latitude": coordinates.latitude,
            "longitude": coordinates.longitude,
            ] as [String: AnyObject]
        print(studentInfo)
        if let locationID = locationID {
            studentInfo["objectId"] = locationID as AnyObject
        }
        
        return StudentDetails(studentInfo)
    }
    
    @objc func keyboardWillChange(notification:Notification) {
        
        if notification.name != NSNotification.Name.UIKeyboardWillShow
        {
            view.frame.origin.y = 0
        }
        else
        {
            if userLocation.isEditing || userURL.isEditing {
                let offset = 0 - getKeyboardHeight(notification)
                view.frame.origin.y = offset
            }
        }
        
    }
    
    func getKeyboardHeight(_ notification:Notification) -> CGFloat {
        
        let userInfo = notification.userInfo
        //let = UIKeyboardFrameEndUserInfoKey
        let keyboardSize = userInfo![UIKeyboardFrameEndUserInfoKey] as! NSValue // of CGRect
        return keyboardSize.cgRectValue.height
    }
    
    func subscribeToKeyboardNotifications() {
        
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillChange(notification:)), name: NSNotification.Name.UIKeyboardWillShow, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillChange(notification:)), name: NSNotification.Name.UIKeyboardWillHide, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillChange(notification:)), name: NSNotification.Name.UIKeyboardWillChangeFrame, object: nil)
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        userLocation.resignFirstResponder()
        userURL.resignFirstResponder()
        return true
    }
    
    func dismissKeyboard() {
        view.endEditing(true)
    }
}
